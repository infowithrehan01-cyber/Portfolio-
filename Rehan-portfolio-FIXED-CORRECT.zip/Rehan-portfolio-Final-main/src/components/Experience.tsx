import React from 'react';
import { Briefcase, GraduationCap, Calendar, Award, CheckCircle2 } from 'lucide-react';

export const Experience: React.FC = () => {
  const experiences = [
    {
      role: 'Senior Full-Stack Developer',
      company: 'TechPulse Solutions',
      location: 'San Francisco, CA (Hybrid)',
      period: '2024 - Present',
      type: 'Full-time',
      description: 'Lead engineer driving frontend and backend architecture for enterprise SaaS clients. Mentoring team members and optimizing server performance.',
      achievements: [
        'Architected high-scale microservices reducing server response latency by 32%',
        'Built modular React design component library adopted across cross-functional teams',
        'Engineered OAuth 2.0 & RBAC authentication pipeline for enterprise compliance',
      ],
      skills: ['React', 'TypeScript', 'Node.js', 'Express', 'Tailwind CSS', 'PostgreSQL', 'Docker'],
    },
    {
      role: 'Full-Stack Web Developer',
      company: 'Innovate Digital Agency',
      location: 'San Francisco, CA',
      period: '2022 - 2024',
      type: 'Full-time',
      description: 'Developed over 15 dynamic web applications and e-commerce platforms for global clients across fintech, health, and retail sectors.',
      achievements: [
        'Integrated Stripe payment gateways handling $250k+ in monthly transactions',
        'Optimized core Web Vitals for e-commerce client achieving 95+ performance scores',
        'Delivered responsive web interfaces with smooth micro-interactions',
      ],
      skills: ['JavaScript', 'React', 'Node.js', 'MongoDB', 'Tailwind CSS', 'REST APIs', 'Git'],
    },
    {
      role: 'Freelance Web Developer',
      company: 'Self-Employed',
      location: 'Remote',
      period: '2021 - 2022',
      type: 'Freelance',
      description: 'Consulted for startups and small businesses to construct bespoke landing pages, custom dashboards, and API integrations.',
      achievements: [
        'Completed 10+ end-to-end web client projects with 100% positive feedback',
        'Implemented Firebase authentication and cloud database sync for web apps',
      ],
      skills: ['HTML5', 'CSS3', 'JavaScript', 'React', 'Firebase', 'Tailwind CSS'],
    },
  ];

  const education = [
    {
      degree: 'Bachelor of Science in Computer Science',
      institution: 'University of California, Berkeley',
      location: 'Berkeley, CA',
      period: '2017 - 2021',
      details: 'Graduated with Honors. Specialized in Software Engineering, Computer Systems, and Web Applications.',
      highlights: ['Dean’s Honor List', 'Lead Organizer - Hackathon 2020', 'Algorithms TA'],
    },
    {
      degree: 'Full-Stack Web Development Certification',
      institution: 'Meta / Coursera Professional Certificate',
      location: 'Online',
      period: '2021',
      details: 'Advanced mastery of React, Node.js, database optimization, and cloud deployment.',
      highlights: ['Top 5% Cohort Score', 'Capstone Project Award'],
    },
  ];

  return (
    <>
      {/* Experience Section */}
      <section id="experience" className="py-20 lg:py-28 bg-white/60 dark:bg-slate-900/40 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
              <Briefcase className="w-4 h-4" />
              <span>CAREER JOURNEY</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
              Work <span className="text-blue-600 dark:text-blue-500">Experience</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
              A timeline of my professional work experience, achievements, and key projects.
            </p>
          </div>

          {/* Timeline List */}
          <div className="relative pl-6 sm:pl-8 border-l-2 border-blue-200 dark:border-slate-700 space-y-10 max-w-4xl mx-auto">
            {experiences.map((exp, idx) => (
              <div key={idx} className="relative group">

                {/* Timeline Dot */}
                <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-blue-600 border-4 border-white dark:border-slate-900 shadow-md group-hover:scale-125 transition-transform" />

                <div className="p-6 sm:p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700/80 shadow-md shadow-blue-500/5 space-y-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white font-heading">
                        {exp.role}
                      </h3>
                      <div className="text-sm font-semibold text-blue-600 dark:text-blue-400 mt-0.5">
                        {exp.company}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-slate-700 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-slate-600 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{exp.period}</span>
                      </span>
                      <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300">
                        {exp.type}
                      </span>
                    </div>
                  </div>

                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                    {exp.description}
                  </p>

                  {/* Achievements Bullet List */}
                  <div className="space-y-2 pt-2">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      Key Accomplishments
                    </div>
                    <ul className="space-y-1.5">
                      {exp.achievements.map((ach, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-200">
                          <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                          <span>{ach}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Skill Badges */}
                  <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-700">
                    {exp.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-50 dark:bg-slate-700/50 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600/50"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Dedicated Education Section */}
      <section id="education" className="py-20 lg:py-28 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
              <GraduationCap className="w-4 h-4" />
              <span>ACADEMIC BACKGROUND</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
              Education & <span className="text-blue-600 dark:text-blue-500">Qualifications</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
              My degrees, academic achievements, and formal technical certifications.
            </p>
          </div>

          {/* Timeline List */}
          <div className="relative pl-6 sm:pl-8 border-l-2 border-blue-200 dark:border-slate-700 space-y-8 max-w-4xl mx-auto">
            {education.map((edu, idx) => (
              <div key={idx} className="relative group">

                {/* Timeline Dot */}
                <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-blue-600 border-4 border-white dark:border-slate-900 shadow-md group-hover:scale-125 transition-transform" />

                <div className="p-6 sm:p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700/80 shadow-md shadow-blue-500/5 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
                        {edu.degree}
                      </h3>
                      <div className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                        {edu.institution}
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-slate-700 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-slate-600">
                      {edu.period}
                    </span>
                  </div>

                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                    {edu.details}
                  </p>

                  <div className="flex flex-wrap gap-2 pt-2">
                    {edu.highlights.map((h) => (
                      <span key={h} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50/80 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-900/40">
                        <Award className="w-3 h-3" />
                        <span>{h}</span>
                      </span>
                    ))}
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>
    </>
  );
};
