import React, { useState } from 'react';
import { ExternalLink, Github, Eye, Sparkles, X, Check, Layers } from 'lucide-react';

export interface Project {
  id: string;
  title: string;
  category: 'fullstack' | 'frontend' | 'ecommerce';
  image: string;
  description: string;
  longDescription: string;
  tags: string[];
  liveUrl: string;
  githubUrl: string;
  keyFeatures: string[];
}

export const Projects: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'fullstack' | 'frontend' | 'ecommerce'>('all');
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);

  const projects: Project[] = [
    {
      id: 'medical-college',
      title: 'Medical College Official Web Portal',
      category: 'fullstack',
      image: '/src/assets/images/project_saas_dashboard_1791364977812.jpg',
      description: 'Comprehensive academic portal for medical students, faculty directory, course curriculum, research publications, and online admissions.',
      longDescription: 'An end-to-end web platform engineered for a leading medical college. It manages student enrollment records, clinical department directories, exam schedules, research paper publishing, and news announcements.',
      tags: ['React', 'Node.js', 'Express', 'TypeScript', 'MongoDB', 'Tailwind CSS'],
      liveUrl: 'https://medical-college-demo.dev',
      githubUrl: 'https://github.com/rehan/medical-college-portal',
      keyFeatures: [
        'Faculty and student portal authentication with role-based access',
        'Searchable medical library research repository and publication catalog',
        'Responsive department directory with office hours and contact info',
      ],
    },
    {
      id: 'bakery-sweets',
      title: 'Bakery & Sweets E-Commerce Store',
      category: 'ecommerce',
      image: '/src/assets/images/project_ecommerce_app_1791364992894.jpg',
      description: 'Delightful online bakery and confectionery shop with custom cake ordering, real-time cart, and local delivery scheduling.',
      longDescription: 'A vibrant e-commerce application crafted for an artisan bakery. Features dynamic cake customization, dietary filters (eggless, gluten-free, sugar-free), automated invoice generation, and local delivery date picker.',
      tags: ['React', 'Tailwind CSS', 'Node.js', 'Express', 'MongoDB'],
      liveUrl: 'https://artisan-bakery-demo.dev',
      githubUrl: 'https://github.com/rehan/bakery-sweets-shop',
      keyFeatures: [
        'Interactive cake customizer with flavor, size, and message preview',
        'Real-time shopping cart drawer with instant local delivery checkout',
        'Responsive mobile grid with high-resolution bakery product gallery',
      ],
    },
    {
      id: 'pharmacy-store',
      title: 'Pharmacy & Medical Store Web App',
      category: 'fullstack',
      image: '/src/assets/images/project_mobile_fitness_1791365027077.jpg',
      description: 'Healthcare e-commerce and inventory platform for prescription medicines, wellness products, and online order tracking.',
      longDescription: 'An intuitive online pharmacy application allowing users to browse medicine categories, upload doctor prescriptions, search OTC health products, and track home delivery orders in real time.',
      tags: ['React', 'Node.js', 'Express', 'MongoDB', 'Tailwind CSS', 'REST APIs'],
      liveUrl: 'https://pharmacy-store-demo.dev',
      githubUrl: 'https://github.com/rehan/pharmacy-store-app',
      keyFeatures: [
        'Prescription upload system with verified pharmacist review workflow',
        'Faceted medicine category search with dosage and manufacturer details',
        'Real-time order tracking pipeline with SMS/Email notification alerts',
      ],
    },
    {
      id: 'doctor-services',
      title: 'Doctor Services & Appointment Booking',
      category: 'fullstack',
      image: '/src/assets/images/project_ai_workspace_1791365014292.jpg',
      description: 'Patient appointment scheduling system with specialist search, slot availability calendar, and medical consultation records.',
      longDescription: 'A modern healthcare appointment web app facilitating direct booking between patients and specialist physicians. Integrates digital consultation slot management, medical history logs, and instant confirmation tickets.',
      tags: ['React', 'TypeScript', 'Node.js', 'Express', 'MySQL', 'Tailwind CSS'],
      liveUrl: 'https://doctor-booking-demo.dev',
      githubUrl: 'https://github.com/rehan/doctor-services-portal',
      keyFeatures: [
        'Interactive doctor directory filterable by specialty, clinic location, and fee',
        'Real-time calendar slot reservation with instant email confirmation ticket',
        'Doctor dashboard for managing daily appointment queue and patient records',
      ],
    },
    {
      id: 'novamobile-store',
      title: 'NovaMobile – Smartphone & Tech Retail Store',
      category: 'ecommerce',
      image: '/src/assets/images/project_ecommerce_app_1791364992894.jpg',
      description: 'Sleek mobile phone and tech accessory storefront with spec comparison table, customer reviews, and multi-currency checkout.',
      longDescription: 'A high-performance e-commerce destination for mobile smartphones and gadgets. Features side-by-side device spec comparison, verified customer ratings, trade-in calculator, and secure checkout pipeline.',
      tags: ['React', 'Node.js', 'Express', 'MongoDB', 'Tailwind CSS'],
      liveUrl: 'https://novamobile-demo.dev',
      githubUrl: 'https://github.com/rehan/novamobile-store',
      keyFeatures: [
        'Side-by-side device specification comparator (screen size, RAM, camera, battery)',
        'Filtered search by brand, price range, operating system, and storage capacity',
        'Mobile-optimized cart experience with fast guest checkout',
      ],
    },
  ];

  const filteredProjects = selectedCategory === 'all'
    ? projects
    : projects.filter((p) => p.category === selectedCategory);

  const filterTabs = [
    { id: 'all', label: 'All Projects' },
    { id: 'fullstack', label: 'Full-Stack' },
    { id: 'ecommerce', label: 'E-Commerce' },
    { id: 'frontend', label: 'Frontend' },
  ];

  return (
    <section id="projects" className="py-20 lg:py-28 bg-white/60 dark:bg-slate-900/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <Layers className="w-4 h-4" />
            <span>PORTFOLIO SHOWCASE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            Featured <span className="text-blue-600 dark:text-blue-500">Projects</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg leading-relaxed">
            Real web applications built for healthcare, education, e-commerce, and digital retail.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 max-w-lg mx-auto mb-10 p-1.5 bg-white dark:bg-slate-800 rounded-2xl border border-blue-100 dark:border-slate-700 shadow-sm">
          {filterTabs.map((tab) => {
            const isActive = selectedCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25'
                    : 'text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100 dark:border-slate-700 shadow-lg shadow-blue-500/5 hover:shadow-2xl hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-300 overflow-hidden flex flex-col group"
            >
              {/* Project Image Container */}
              <div className="relative h-56 overflow-hidden bg-slate-900">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                {/* Category Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/90 dark:bg-slate-900/90 backdrop-blur-md text-blue-600 dark:text-blue-400 shadow-sm">
                    {project.category === 'fullstack' ? 'Full-Stack' : project.category === 'ecommerce' ? 'E-Commerce' : 'Frontend'}
                  </span>
                </div>

                {/* Quick View Button */}
                <button
                  onClick={() => setActiveProjectModal(project)}
                  className="absolute bottom-4 right-4 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-blue-600 text-white text-xs font-semibold shadow-md opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Case Study</span>
                </button>
              </div>

              {/* Project Details Content */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
                <div className="space-y-2.5">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-300 text-xs sm:text-sm leading-relaxed">
                    {project.description}
                  </p>
                </div>

                {/* Tech Badges */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-blue-50/80 dark:bg-slate-700/60 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-slate-600/50"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Card Action Footer */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between gap-3">
                  <button
                    onClick={() => setActiveProjectModal(project)}
                    className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                  >
                    <span>View Details</span>
                    <span>→</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 transition-colors"
                      title="View GitHub Repository"
                    >
                      <Github className="w-4 h-4" />
                    </a>
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition-colors"
                    >
                      <span>Live Demo</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Project Detail Modal */}
      {activeProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-blue-100 dark:border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6">

            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  {activeProjectModal.category} Project
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading mt-1">
                  {activeProjectModal.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveProjectModal(null)}
                className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Description */}
            <div className="space-y-4">
              <h4 className="text-base font-bold text-slate-900 dark:text-white">Architecture & Overview</h4>
              <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                {activeProjectModal.longDescription}
              </p>

              {/* Key Features List */}
              <div className="space-y-2 pt-2">
                <h5 className="text-xs font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Key Highlights</h5>
                <ul className="space-y-2">
                  {activeProjectModal.keyFeatures.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-200">
                      <div className="p-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
              <a
                href={activeProjectModal.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs sm:text-sm hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
              >
                <Github className="w-4 h-4" />
                <span>GitHub Repository</span>
              </a>
              <a
                href={activeProjectModal.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/20 flex items-center gap-2"
              >
                <span>Launch Live Website</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
