import React from 'react';
import { Code, Zap, Heart, Target, MapPin, Mail, Phone, Calendar, Download, CheckCircle2 } from 'lucide-react';

interface AboutProps {
  onOpenResume: () => void;
}

export const About: React.FC<AboutProps> = ({ onOpenResume }) => {
  const techBadges = [
    { name: 'HTML', color: 'bg-orange-50 text-orange-600 border-orange-200 dark:bg-orange-950/40 dark:text-orange-400 dark:border-orange-800' },
    { name: 'CSS', color: 'bg-blue-50 text-blue-600 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800' },
    { name: 'JavaScript', color: 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800' },
    { name: 'React', color: 'bg-sky-50 text-sky-600 border-sky-200 dark:bg-sky-950/40 dark:text-sky-400 dark:border-sky-800' },
    { name: 'Node.js', color: 'bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800' },
  ];

  const featureCards = [
    {
      icon: Code,
      title: 'Clean Code',
      description: 'Well-structured, scalable and maintainable code built following best practices and design patterns.',
    },
    {
      icon: Zap,
      title: 'Fast Performance',
      description: 'Optimized for speed, high Lighthouse scores, seamless interactivity, and exceptional user experience.',
    },
    {
      icon: Heart,
      title: 'Always Learning',
      description: 'Continuously exploring emerging technologies, frameworks, and modern architecture patterns.',
    },
    {
      icon: Target,
      title: 'Client Focus',
      description: 'Delivering tailored digital products that align with real business goals and end-user needs.',
    },
  ];

  const personalDetails = [
    { label: 'Location', value: 'San Francisco, CA (Remote available)', icon: MapPin },
    { label: 'Email', value: 'infowithrehan01@gmail.com', icon: Mail },
    { label: 'Phone', value: '+1 (555) 019-2834', icon: Phone },
    { label: 'Availability', value: 'Open for Freelance & Full-time', icon: Calendar },
  ];

  return (
    <section id="about" className="py-20 lg:py-28 bg-white/60 dark:bg-slate-900/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="space-y-3 mb-12">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
            <span>ABOUT ME</span>
            <span className="w-12 h-0.5 bg-blue-600/60 dark:bg-blue-400/60 rounded-full" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white font-heading tracking-tight">
            Turning Ideas Into <span className="text-blue-600 dark:text-blue-500">Digital Solutions</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg max-w-2xl leading-relaxed">
            I'm Rehan, a passionate full-stack developer with a love for building beautiful, functional, and user-friendly web applications.
          </p>

          {/* Technology Pills */}
          <div className="flex flex-wrap items-center gap-2.5 pt-3">
            {techBadges.map((tech) => (
              <span
                key={tech.name}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold border ${tech.color} shadow-2xs`}
              >
                {tech.name}
              </span>
            ))}
          </div>
        </div>

        {/* Two Column Grid: Left Personal Overview & Info, Right Feature Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">

          {/* Left Column - Detailed Bio & Quick Details */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-7 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100/80 dark:border-slate-700/80 shadow-lg shadow-blue-500/5 space-y-5">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Professional Profile</h3>
              <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
                With over 3 years of hands-on software development experience, I specialize in crafting robust web applications end-to-end. My expertise spans frontend engineering with React and TypeScript to backend architecture using Node.js, Express, databases, and cloud services.
              </p>
              <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
                I pride myself on writing clean, scalable code, prioritizing user accessibility, and delivering intuitive interfaces that engage users and drive business success.
              </p>

              {/* Personal Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100 dark:border-slate-700/80">
                {personalDetails.map((detail) => (
                  <div key={detail.label} className="flex items-start gap-3">
                    <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700/60 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5">
                      <detail.icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs text-slate-400 dark:text-slate-500 font-medium">{detail.label}</div>
                      <div className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">{detail.value}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Download Resume Button */}
              <div className="pt-2">
                <button
                  onClick={onOpenResume}
                  className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Resume (PDF)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column - 4 Feature Cards matching reference visual style */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-5">
            {featureCards.map((card) => (
              <div
                key={card.title}
                className="p-6 rounded-3xl bg-white dark:bg-slate-800/90 border border-blue-100/80 dark:border-slate-700/80 shadow-md shadow-blue-500/5 hover:shadow-xl hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mb-4 shadow-md shadow-blue-500/25 group-hover:scale-110 transition-transform duration-300">
                  <card.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">{card.title}</h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {card.description}
                </p>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
