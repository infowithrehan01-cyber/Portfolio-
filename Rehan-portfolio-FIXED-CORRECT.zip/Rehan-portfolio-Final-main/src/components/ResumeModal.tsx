import React from 'react';
import { X, Download, FileText, Mail, Phone, MapPin, Globe, CheckCircle2 } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (message: string, type: 'success' | 'error') => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, onShowToast }) => {
  if (!isOpen) return null;

  const handleDownloadPDF = () => {
    // Generate text/markdown format or trigger browser print/download dialog
    const resumeText = `
REHAN - FULL-STACK DEVELOPER
Email: infowithrehan01@gmail.com | Phone: +1 (555) 019-2834 | Location: San Francisco, CA
Portfolio: https://rehan-portfolio.dev | GitHub: https://github.com

SUMMARY
Passionate Full-Stack Developer with 3+ years of experience engineering high-performance web applications, scalable REST APIs, and modern user interfaces.

SKILLS
Frontend: React, TypeScript, JavaScript (ES6+), HTML5, CSS3, Tailwind CSS, Next.js
Backend: Node.js, Express.js, RESTful APIs, GraphQL
Databases & Cloud: MongoDB, MySQL, PostgreSQL, Firebase, Git/GitHub, Docker

EXPERIENCE
Senior Full-Stack Developer - TechPulse Solutions (2024 - Present)
Full-Stack Web Developer - Innovate Digital Agency (2022 - 2024)
Freelance Software Developer - Self-Employed (2021 - 2022)

EDUCATION
B.S. in Computer Science - University of California, Berkeley (2017 - 2021)
    `;

    const blob = new Blob([resumeText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Rehan_Full_Stack_Developer_Resume.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onShowToast('Resume downloaded successfully!', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-blue-100 dark:border-slate-800 shadow-2xl p-6 sm:p-10 space-y-8">

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-md shadow-blue-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-heading">
                Rehan's Curriculum Vitae
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Official Full-Stack Engineering Resume
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPDF}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/20"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>

            <button
              onClick={onClose}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Resume Sheet Preview */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-6 text-slate-800 dark:text-slate-100">

          {/* Resume Header */}
          <div className="border-b border-slate-200 dark:border-slate-700 pb-6 space-y-2">
            <h1 className="text-3xl font-extrabold font-heading text-slate-900 dark:text-white">Rehan</h1>
            <h2 className="text-base font-bold text-blue-600 dark:text-blue-400">Full-Stack Software Engineer</h2>
            <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-slate-600 dark:text-slate-300 pt-1">
              <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5 text-blue-600" /> infowithrehan01@gmail.com</span>
              <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5 text-blue-600" /> +1 (555) 019-2834</span>
              <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-blue-600" /> San Francisco, CA</span>
            </div>
          </div>

          {/* Summary */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Professional Summary</h3>
            <p className="text-xs sm:text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              Versatile Full-Stack Engineer with 3+ years of experience designing and deploying scalable web products. Expert in React, TypeScript, Node.js, Express, databases, and responsive UI architecture.
            </p>
          </div>

          {/* Technical Skills */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Core Technical Competencies</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                <span className="font-bold block text-slate-900 dark:text-white mb-1">Frontend</span>
                <span>React, TypeScript, JavaScript, HTML5, CSS3, Tailwind CSS, Next.js</span>
              </div>
              <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                <span className="font-bold block text-slate-900 dark:text-white mb-1">Backend</span>
                <span>Node.js, Express.js, REST APIs, GraphQL, Microservices</span>
              </div>
              <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                <span className="font-bold block text-slate-900 dark:text-white mb-1">Databases & Cloud</span>
                <span>MongoDB, MySQL, PostgreSQL, Firebase, Git/GitHub, Docker</span>
              </div>
            </div>
          </div>

          {/* Experience */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Work History</h3>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                  <span>Senior Full-Stack Developer · TechPulse Solutions</span>
                  <span className="text-blue-600 dark:text-blue-400">2024 - Present</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 mt-1">Lead frontend/backend engineering for SaaS clients, reducing latency by 32%.</p>
              </div>

              <div>
                <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                  <span>Full-Stack Web Developer · Innovate Digital Agency</span>
                  <span className="text-blue-600 dark:text-blue-400">2022 - 2024</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 mt-1">Built 15+ full-stack web applications and integrated multi-currency payment pipelines.</p>
              </div>
            </div>
          </div>

          {/* Education */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Education</h3>
            <div className="text-xs flex justify-between font-bold text-slate-900 dark:text-white">
              <span>B.S. Computer Science · University of California, Berkeley</span>
              <span className="text-blue-600 dark:text-blue-400">2017 - 2021</span>
            </div>
          </div>

        </div>

        {/* Action Footer */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs sm:text-sm"
          >
            Close
          </button>
          <button
            onClick={handleDownloadPDF}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-500/20 flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Download Resume</span>
          </button>
        </div>

      </div>
    </div>
  );
};
