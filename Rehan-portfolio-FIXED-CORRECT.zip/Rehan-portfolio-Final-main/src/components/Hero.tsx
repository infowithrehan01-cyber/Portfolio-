import React, { useState, useEffect } from 'react';
import { Code2, Send, Mail, Github, Linkedin, Twitter, Instagram, Calendar, TrendingUp, Briefcase, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import rehanProfile from '../assets/images/rehan-profile.png';

interface HeroProps {
  onOpenResume: () => void;
}

export const Hero: React.FC<HeroProps> = () => {
  // Rotating typing titles list requested by user
  const titles = [
    'Full-Stack Developer',
    'Frontend Developer',
    'Backend Developer',
    'Web Developer',
    'JavaScript Developer',
    'React Developer',
  ];

  // Typing animation state
  const [currentTitleIndex, setCurrentTitleIndex] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const fullText = titles[currentTitleIndex];

    const handleTyping = () => {
      if (!isDeleting) {
        // Typing phase
        setCurrentText(fullText.substring(0, currentText.length + 1));
        if (currentText === fullText) {
          // Pause at full text
          setTimeout(() => setIsDeleting(true), 2000);
          return;
        }
      } else {
        // Deleting phase
        setCurrentText(fullText.substring(0, currentText.length - 1));
        if (currentText === '') {
          setIsDeleting(false);
          setCurrentTitleIndex((prev) => (prev + 1) % titles.length);
          return;
        }
      }
    };

    const typingSpeed = isDeleting ? 40 : 80;
    const timer = setTimeout(handleTyping, typingSpeed);

    return () => clearTimeout(timer);
  }, [currentText, isDeleting, currentTitleIndex]);

  // Calendar state matching October 2026 from reference design
  const [selectedDate, setSelectedDate] = useState(6);
  const [currentMonth, setCurrentMonth] = useState('October 2026');

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const calendarDays = [5, 6, 7, 8, 9, 10, 11];

  return (
    <section id="home" className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden">
      {/* Background Soft Blue Glow Effect matching reference */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-gradient-to-tr from-blue-200/50 via-sky-100/40 to-indigo-100/20 dark:from-blue-950/40 dark:via-sky-950/30 dark:to-slate-900/0 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center">

          {/* Left Column - Hero Content (approx 5 cols) */}
          <div className="lg:col-span-5 space-y-6 text-center lg:text-left">
            {/* Status Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/90 dark:bg-blue-950/90 border border-blue-200 dark:border-blue-800/80 text-blue-700 dark:text-blue-300 text-xs font-bold uppercase tracking-wider shadow-2xs">
              <Code2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Available for impactful work</span>
            </div>

            {/* Headline Title */}
            <div className="space-y-2">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.1]">
                Hi, I’m
                <span className="block text-blue-600 dark:text-blue-500 font-extrabold text-5xl sm:text-6xl lg:text-7xl mt-1 tracking-tight">
                  Rehan
                </span>
              </h1>

              {/* Animated Typing Role Title */}
              <div className="h-12 flex items-center justify-center lg:justify-start">
                <span className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-800 dark:text-slate-100 font-heading">
                  {currentText}
                  <span className="inline-block w-0.5 h-7 ml-1 bg-blue-600 dark:bg-blue-400 animate-pulse align-middle" />
                </span>
              </div>
            </div>

            {/* Intro Paragraph */}
            <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
              I build modern, responsive, high-performing web applications that blend elegant design with reliable engineering.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Send className="w-4 h-4" />
                <span>View My Work</span>
                <span className="text-base">→</span>
              </a>

              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 font-semibold text-sm shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Mail className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Contact Me</span>
              </a>
            </div>

            {/* Social Media Links */}
            <div className="flex items-center justify-center lg:justify-start gap-5 pt-3">
              {[
                { name: 'GitHub', icon: Github, href: 'https://github.com' },
                { name: 'LinkedIn', icon: Linkedin, href: 'https://linkedin.com' },
                { name: 'Twitter', icon: Twitter, href: 'https://twitter.com' },
                { name: 'Instagram', icon: Instagram, href: 'https://instagram.com' },
              ].map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noreferrer"
                  className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:border-blue-300 dark:hover:border-blue-600 shadow-2xs hover:scale-110 transition-all"
                  aria-label={social.name}
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Center Column - Portrait Card matching reference image (approx 4 cols) */}
          <div className="lg:col-span-4 flex justify-center">
            <div className="relative group max-w-sm sm:max-w-md w-full">
              {/* Outer soft shadow aura */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-400 dark:from-blue-600 dark:to-indigo-600 rounded-[2.2rem] blur-xl opacity-35 group-hover:opacity-60 transition duration-500" />

              {/* Portrait Container */}
              <div className="relative rounded-[2rem] overflow-hidden border-4 border-white dark:border-slate-800 bg-slate-900 shadow-2xl transition-transform duration-300 group-hover:scale-[1.01]">
                <img
                  src={rehanProfile}
                  alt="Rehan - Full-Stack Developer"
                  className="w-full h-[420px] sm:h-[480px] object-cover object-center"
                />

                {/* Subtle scrim overlay at bottom */}
                <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex items-end justify-between p-4 text-white">
                  <div>
                    <div className="font-bold text-sm tracking-tight">Rehan</div>
                    <div className="text-[11px] text-blue-300 font-medium">Full-Stack Developer</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Status & Stats Cards matching reference image (approx 3 cols) */}
          <div className="lg:col-span-3 space-y-5">

            {/* Current Status Widget */}
            <div className="p-5 rounded-2xl bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border border-blue-100 dark:border-slate-700 shadow-lg shadow-blue-500/5 hover:border-blue-300 dark:hover:border-blue-600 transition-all">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">Current Status</h3>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Available for freelance / full-time</span>
                  </div>
                </div>
              </div>

              {/* Calendar Widget */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700">
                <div className="flex items-center justify-between mb-3 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <button
                    onClick={() => setCurrentMonth('October 2026')}
                    className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-slate-800 dark:text-slate-200">{currentMonth}</span>
                  <button
                    onClick={() => setCurrentMonth('November 2026')}
                    className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-7 gap-1 text-center">
                  {weekDays.map((day) => (
                    <span key={day} className="text-[10px] font-medium text-slate-400 dark:text-slate-500 uppercase">
                      {day}
                    </span>
                  ))}
                  {calendarDays.map((day) => {
                    const isSelected = selectedDate === day;
                    return (
                      <button
                        key={day}
                        onClick={() => setSelectedDate(day)}
                        className={`py-1.5 text-xs font-semibold rounded-full transition-colors ${
                          isSelected
                            ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-700'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Statistics Card */}
            <div className="p-5 rounded-2xl bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border border-blue-100 dark:border-slate-700 shadow-lg shadow-blue-500/5 space-y-4">
              {/* Stat 1 */}
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">3+</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Years building digital products</div>
                </div>
              </div>

              {/* Stat 2 */}
              <div className="flex items-start gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">20+</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Projects shipped and refined</div>
                </div>
              </div>

              {/* Stat 3 */}
              <div className="flex items-start gap-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                <div className="p-2 rounded-xl bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                  <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                </div>
                <div>
                  <div className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">100%</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Passion for clean code & great UI</div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
